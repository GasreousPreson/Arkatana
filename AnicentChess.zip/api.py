"""
api.py  (第6版：接入时间控制 + 评分系统)
==========================================
运行方式（终端里，确保在项目文件夹下）：

    uvicorn api:app --reload

然后打开 http://127.0.0.1:8000/docs 测试各个接口。

设计说明：
    - 对局状态仍然优先保存在内存里的 GAMES 字典中（{game_id: Game 实例}），
      访问速度快；但每次创建/走棋/悔棋/认输之后都会调用 db.save_game()
      同步落盘到 SQLite/PostgreSQL。
    - 如果内存里找不到某个对局（比如服务器重启过），get_game_or_404()
      会自动尝试从数据库读取并回放重建；同时会顺带做一次"惰性超时检测"——
      每次有人跟这局对局交互，都会检查当前行棋方是不是已经超时。
    - 账号与对局的绑定：创建对局时，登录用户可以指定执黑/执白/随机；
      另一个登录用户可以调用 /games/{id}/join 认领剩下的一方。
      一旦某一方绑定了账号，走棋/悔棋/认输都会校验调用者身份。
      完全不登录也可以创建和游玩，此时是纯匿名对局，不做任何身份限制。
    - 时间控制与棋钟：创建对局时可以指定 minutes_per_side/increment_seconds
      （留空表示无时间限制）。棋钟什么时候开始走是有讲究的——纯匿名对局
      创建即开始计时；绑定了账号、还留着空位等人加入的房间，
      要等 /join 把最后一个空位填满才开始。
    - rated（排位）对局：只能随机先后手，必须设置时间控制。
      对局分出胜负后会自动触发评分结算（db.finalize_rated_game 内部
      有防重复触发保护）。
    - WebSocket（/ws/games/{game_id}）：连接后立即收到当前状态，
      之后每次走棋/悔棋/认输/加入都会自动收到最新状态推送，
      不需要客户端手动刷新或轮询。
    - 棋盘状态用 JSON 格式返回：{坐标字符串: {piece, side, promoted}}，
      方便未来前端直接用这份数据渲染棋盘。
    - 坐标统一用 "d5" 这种字符串格式在网络层传输，
      进出 Game/board 内部时再转换成 (col, row) 元组。
"""

from __future__ import annotations
import asyncio
import uuid
import secrets
import random
import time
import os
import sys

from fastapi import FastAPI, HTTPException, Header, WebSocket, WebSocketDisconnect, Security, BackgroundTasks
from fastapi.security import APIKeyHeader
from fastapi.staticfiles import StaticFiles
from starlette.concurrency import run_in_threadpool
from pydantic import BaseModel
from google.oauth2 import id_token as google_id_token
from google.auth.transport import requests as google_requests

from board import parse_coord, coord_to_str
from pieces import Side, Throne
from game import Game, IllegalMoveError, GameOverError
from layout import setup_initial_board
from notation import format_game, move_notation, position_string_to_board
from rules import is_in_check, GameResult
from clock import TimeControl
import db

# 找 ai/ 目录：不同仓库结构下 ai/ 相对 api.py 的位置不一样——
#   - api.py 就在仓库根目录，ai/ 在同一层：  repo/api.py ,  repo/ai/play_service.py
#   - api.py 在后端子目录里，ai/ 跟那个子目录同层：repo/AnicentChess/api.py , repo/ai/play_service.py
# 两种都试一遍，不用猜哪种对——猜错了就是现在这个 ModuleNotFoundError 的根因。
# 如果你的仓库结构跟这两种都不一样，把 ARKATANA_AI_DIR 环境变量设成 ai/ 目录的
# 实际绝对路径即可，不用改这里的代码。
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_AI_DIR_CANDIDATES = [
    os.environ.get("ARKATANA_AI_DIR", ""),
    os.path.join(_THIS_DIR, "ai"),            # api.py 和 ai/ 同一层
    os.path.join(_THIS_DIR, "..", "ai"),       # api.py 在子目录里，ai/ 跟子目录同层
]
_AI_DIR = next((p for p in _AI_DIR_CANDIDATES if p and os.path.isfile(os.path.join(p, "play_service.py"))), None)
if _AI_DIR is None:
    raise RuntimeError(
        "找不到 ai/play_service.py，试过的路径：" + ", ".join(p for p in _AI_DIR_CANDIDATES if p) +
        "。请确认 ai/ 文件夹已经放进仓库，或者设置环境变量 ARKATANA_AI_DIR 指向它的绝对路径。"
    )
if _AI_DIR not in sys.path:
    sys.path.insert(0, _AI_DIR)
import play_service
import bot_controller
from personas import PERSONAS

# 人格账号的用户名直接用 display_name（比如"Kanderson"）——这样大厅/对局
# 历史里显示的名字就是人格名，不需要专门再做一次"内部key -> 展示名"的转换
# 给前端看。PERSONA_USERNAME_TO_KEY 反过来查："这个用户名是哪个人格"，
# 调度器和出招触发逻辑都靠它判断"轮到走棋的这一方是不是 bot"。
PERSONA_USERNAME_TO_KEY: dict[str, str] = {p.display_name: key for key, p in PERSONAS.items()}
BOT_ORDER: list[str] = list(PERSONAS.keys())  # 轮转顺序——就用 personas.py 里定义的顺序

BOT_SCHEDULER_STATE = bot_controller.SchedulerState()


app = FastAPI(title="Arkatana API", version="0.7.0")


@app.on_event("startup")
async def _on_startup() -> None:
    """服务启动时跑一次：
        1. 确保9个 AI 人格账号都存在于数据库（幂等，重复部署/重启不会出问题）。
        2. 启动 AI 自主建房的后台循环。
    seed_bot_accounts 本身是同步的数据库操作，量很小（9条，且大多数时候
    都是"已存在，直接跳过"），用 run_in_threadpool 意思一下、不占用事件循环
    起步的这一小段时间就行，不需要更复杂的处理。
    """
    username_to_elo = {p.display_name: p.elo for p in PERSONAS.values()}
    await run_in_threadpool(db.seed_bot_accounts, username_to_elo)
    asyncio.create_task(_bot_scheduler_loop())

# 注册一个具名的安全方案，Swagger 页面右上角会出现一个"Authorize"锁头按钮，
# 登录后把 token 粘贴进去点一次，之后所有接口请求会自动带上，不用每个接口都手填。
auth_scheme = APIKeyHeader(name="X-Auth-Token", auto_error=False)

# Google 登录用的 Client ID（这个不是密钥，前端也会用到同一个值，
# 但还是放进环境变量里方便以后换项目/换环境时不用改代码）。
GOOGLE_CLIENT_ID = os.environ.get("GOOGLE_CLIENT_ID", "")

# 启动时建表（如果表已存在，这行不会做任何事，可以放心每次都调用）
db.init_db()

# 托管前端静态文件：frontend/ 文件夹里的 index.html 等文件，
# 通过 http://127.0.0.1:8000/app/ 访问。
# 这样前端和后端同源，浏览器里 fetch('/games') 不会有跨域问题。
app.mount("/app", StaticFiles(directory="frontend", html=True), name="frontend")

# 内存对局存储：{game_id: Game 实例}
GAMES: dict[str, Game] = {}

# 内存对局玩家绑定：{game_id: {"black": username|None, "white": username|None}}
# 服务器重启后会从数据库里的 black_player/white_player 字段重新读取补全。
GAME_PLAYERS: dict[str, dict] = {}

# 内存对局的 rated 标记缓存：{game_id: bool}
GAME_RATED: dict[str, bool] = {}

# 匿名访客的身份绑定：{game_id: {"black": guest_id|None, "white": guest_id|None}}
# 跟 GAME_PLAYERS 是平行的两套机制——GAME_PLAYERS 认的是登录账号，
# 这套认的是浏览器本地生成的"访客ID"（没有账号、不会持久化到数据库，
# 服务器重启后清空，纯粹用来区分"匿名对局里到底是不是同一个人在操作"）。
GAME_GUEST_CLAIMS: dict[str, dict] = {}

# 悔棋/和棋的协商状态（都是临时性的，服务器重启后清空，不需要持久化）
#   GAME_OFFERS   : {game_id: {"kind": "retake"|"draw", "from": "black"|"white"}}
#                   同一局同时最多只有一个待处理的提议
#   GAME_COOLDOWN : {game_id: {("black","draw"): 可以再次提出的时间戳, ...}}
#                   被拒绝后 60 秒内不能再提同一类提议
#   GAME_DRAW_COUNT: {game_id: {"black": 已提和次数, "white": ...}}
#                   每方最多提和 2 次
GAME_OFFERS: dict[str, dict] = {}
GAME_COOLDOWN: dict[str, dict] = {}
GAME_DRAW_COUNT: dict[str, dict] = {}

# 对局结束时的评分变化（只有 rated + 双方都注册 + 分出胜负 才会有值）：
# {game_id: {"black": {"before": 旧分, "after": 新分, "delta": 差值}, "white": {...}}}
# 终局结算弹窗用这个显示"+14 / -13"式的升降箭头。
GAME_RATING_DELTAS: dict[str, dict] = {}

OFFER_COOLDOWN_SECONDS = 60
MAX_DRAW_OFFERS_PER_SIDE = 2

# "Single game"（单设备本机对战，两人轮流用同一个浏览器）用的临时对局：
# 完全不写数据库——不出现在大厅、Game History、Database 里，
# 服务器重启就没了，就是一次性的本地演练，不是真正意义上的"一局对局"。
EPHEMERAL_GAMES: set[str] = set()

# Play against AI 用的对局标记：{game_id: {"side": "black"|"white", "difficulty": "easy"|"medium"|"hard"}}
# 只标记"哪一方是AI、用什么难度"——AI 那一方在 GAME_PLAYERS 里存的是一个固定的
# 展示名字（比如"🤖 AI（中等）"），不是真实用户名，这样能顺手复用现有的走棋权限
# 校验（没有真人能以这个名字登录，自然没人能替AI手动走棋）和前端玩家名渲染逻辑，
# 不需要为 AI 专门加一整套机制。细节见 create_game() 和 trigger_ai_move()。
GAME_AI: dict[str, dict] = {}

# 内存登录令牌存储：{token: username}
# 注意：这是临时方案，服务器重启后所有人都需要重新登录。
# 以后如果需要"记住登录状态"，可以把这张表也存进数据库。
TOKENS: dict[str, str] = {}


class ConnectionManager:
    """
    管理 WebSocket 连接：记录"谁正在围观哪局对局"，
    并在对局状态变化时把最新状态广播给所有围观者。
    """

    def __init__(self):
        self.active: dict[str, list[WebSocket]] = {}

    async def connect(self, game_id: str, websocket: WebSocket) -> None:
        await websocket.accept()
        self.active.setdefault(game_id, []).append(websocket)

    def disconnect(self, game_id: str, websocket: WebSocket) -> None:
        conns = self.active.get(game_id)
        if conns and websocket in conns:
            conns.remove(websocket)
            if not conns:
                del self.active[game_id]

    async def broadcast(self, game_id: str, message: dict) -> None:
        conns = list(self.active.get(game_id, []))
        for ws in conns:
            try:
                await ws.send_json(message)
            except Exception:
                # 连接已经断了但还没被清理，直接移除，不影响其他人收消息
                self.disconnect(game_id, ws)


manager = ConnectionManager()


# ---------------------------------------------------------------------------
# 请求体格式（Pydantic 模型，FastAPI 会自动校验请求数据格式是否正确）
# ---------------------------------------------------------------------------

class MoveRequest(BaseModel):
    from_sq: str   # 例如 "d5"
    to_sq: str     # 例如 "d7"


class ResignRequest(BaseModel):
    side: str      # "black" 或 "white"


class OfferRequest(BaseModel):
    kind: str      # "retake"（悔棋）或 "draw"（提和）


class OfferResponseRequest(BaseModel):
    accept: bool   # True=同意，False=拒绝


class CreateGameRequest(BaseModel):
    side_preference: str = "random"     # "black" / "white" / "random"（对 AI 对局来说，
                                          # 这里指的是"人类想执哪一方"，AI 拿另一方）
    rated: bool = False
    minutes_per_side: int | None = None  # None 表示无时间限制（比如"线下对练"）
    increment_seconds: int = 0
    single_device: bool = False          # True = "Single game"：同一台设备两人轮流下，
                                          # 不落库、不认领任何一方（双方都能操作）
    vs_ai: bool = False                  # True = Play against AI：另一方由 AI 控制
    ai_difficulty: str = "medium"        # "easy" / "medium" / "hard"，只在 vs_ai=True 时有意义


class RegisterRequest(BaseModel):
    username: str
    password: str


class LoginRequest(BaseModel):
    username: str
    password: str


class OAuthLoginRequest(BaseModel):
    credential: str  # Google 返回的 ID token（一段 JWT 字符串）


# ---------------------------------------------------------------------------
# 内部工具函数
# ---------------------------------------------------------------------------

def board_to_json(board) -> dict:
    """把棋盘转换成 JSON 友好的格式：{坐标字符串: {棋子缩写, 中文符号, 阵营, 是否升变}}"""
    result = {}
    for coord in board.occupied_coords():
        piece = board.get(coord)
        result[coord_to_str(*coord)] = {
            "piece": piece.notation,
            "symbol": piece.symbol,
            "side": piece.side.value,
            "promoted": piece.promoted,
        }
    return result


def game_state(game_id: str, game: Game) -> dict:
    """组装一局对局当前状态的完整 JSON 响应"""
    players = get_players_cached(game_id)
    clock = game.clock

    if clock.is_unlimited:
        time_info = {"time_control": None, "black_time": None, "white_time": None}
    else:
        time_info = {
            "time_control": {
                "minutes_per_side": clock.time_control.minutes_per_side,
                "increment_seconds": clock.time_control.increment_seconds,
            },
            "black_time": clock.time_left("black"),
            "white_time": clock.time_left("white"),
        }

    last_move_record = game.move_log[-1] if game.move_log else None

    # 当前行棋方每颗棋子各自能走到哪些格子，一次性全给前端。
    # 这样点选棋子时可以本地查表立刻高亮，不用每次点击都往返一次服务器——
    # 对跨国访问来说，省掉的这次往返就是"点一下卡一下"的主要来源。
    # 代价只是响应体稍大一点，比多次往返划算得多。
    legal_map: dict[str, list[str]] = {}
    for move in game.legal_moves():
        legal_map.setdefault(coord_to_str(*move.from_sq), []).append(coord_to_str(*move.to_sq))

    ai_info = GAME_AI.get(game_id)

    return {
        "game_id": game_id,
        "current_side": game.current_side.value,
        "result": game.result.value,
        "move_count": len(game.move_log),
        "board": board_to_json(game.board),
        "black_player": players["black"],
        "white_player": players["white"],
        "rated": GAME_RATED.get(game_id, False),
        "ai_side": ai_info["side"] if ai_info else None,       # "black"/"white"/None——
        "ai_difficulty": ai_info["difficulty"] if ai_info else None,  # 这两个字段只覆盖
                                                                        # Play against AI 那条
                                                                        # 历史路径（GAME_AI
                                                                        # 记录的难度选择）
        # black_is_bot/white_is_bot 覆盖**所有**bot情形（vs_ai 难度选择 +
        # AI 人格大厅自主对局），前端要判断"这一方是不是bot"（比如要不要
        # 跳过评分查询）应该用这两个字段，不要只看 ai_side——那个字段
        # 检测不到人格账号在大厅正常配对到的对局。
        "black_is_bot": players["black"] in PERSONA_USERNAME_TO_KEY or ai_info and ai_info["side"] == "black",
        "white_is_bot": players["white"] in PERSONA_USERNAME_TO_KEY or ai_info and ai_info["side"] == "white",
        "clock_started": game.clock.active_side is not None,
        "in_check": is_in_check(game.board, game.current_side) if game.result.value == "ongoing" else False,
        "pending_offer": GAME_OFFERS.get(game_id),
        "end_reason": game.end_reason.value if game.end_reason else None,
        "rating_delta": GAME_RATING_DELTAS.get(game_id),
        "legal_moves": legal_map,
        "last_move_from": coord_to_str(*last_move_record.from_sq) if last_move_record else None,
        "last_move_to": coord_to_str(*last_move_record.to_sq) if last_move_record else None,
        **time_info,
    }


def get_game_or_404(game_id: str) -> Game:
    game = GAMES.get(game_id)
    if game is None:
        # 内存里没有（比如服务器刚重启过），尝试从数据库读取重建
        restored = db.load_game(game_id)
        if restored is None:
            raise HTTPException(status_code=404, detail=f"找不到对局 ID: {game_id}")
        GAMES[game_id] = restored
        GAME_RATED[game_id] = db.is_rated(game_id)
        game = restored

    # 惰性超时检测：每次有人跟这局对局交互（不只是走棋），
    # 顺带看一眼当前行棋方是不是已经超时，超时就直接结束对局。
    if game.check_timeout():
        # 这里直接用同步写库，没有走 persist()——因为 get_game_or_404 被十几个
        # 接口调用，把它整个改成 async 会牵连过广、风险大于收益；而超时这件事
        # 每局最多只发生一次，不在热路径上，偶尔阻塞一下可以接受。
        if game_id not in EPHEMERAL_GAMES:
            db.save_game(game_id, game)
        maybe_finalize_rating(game_id, game)

    return game


async def persist(
    game_id: str,
    game: Game,
    black_player: str | None = None,
    white_player: str | None = None,
    rated: bool | None = None,
    was_random_side: bool | None = None,
) -> None:
    """
    把当前对局状态存入数据库（每次影响状态的操作后都应调用）。

    关键：db.save_game() 用的是**同步阻塞**的数据库驱动（psycopg2）。
    如果直接在 async 接口里调用它，那次数据库往返期间会卡住整个事件循环——
    不只是走这步棋的人在等，服务器上**所有人**的请求都会一起排队等它完成。
    这正是"两人正常对弈时也会突然集体卡十几秒"的根源：只要某一次写库
    因为任何原因慢了（网络抖动、Neon 端偶发延迟、连接重建），全服跟着冻住。

    所以这里丢进线程池执行：这次写库慢的时候，只有发起它的这个请求在等，
    其他人的请求照常被事件循环处理。
    """
    if game_id in EPHEMERAL_GAMES:
        return  # single game：压根不落库，不计入大厅/历史/对局库
    await run_in_threadpool(
        db.save_game,
        game_id, game,
        black_player=black_player, white_player=white_player, rated=rated,
        was_random_side=was_random_side,
    )


def maybe_finalize_rating(game_id: str, game: Game) -> None:
    """
    对局刚结束时调用：如果是 rated 对局，尝试触发评分结算。
    db.finalize_rated_game 内部已经做好了各种前提条件检查
    （是否rated、双方是否都注册、是否有时间控制、是否已经结算过），
    这里只需要负责"游戏一结束就调用一下"，不需要重复判断。
    """
    if game.result == GameResult.ONGOING:
        return
    if game.result == GameResult.DRAW:
        # 评分公式目前只处理分出胜负的对局（rating.py 的 apply_game_result
        # 只接受 "black"/"white"）。和棋按标准 Elo 应该各算 0.5 分，
        # 这需要扩展评分模块，暂时先不结算，避免把和棋错算成某一方获胜。
        return
    winner = "black" if game.result == GameResult.BLACK_WINS else "white"

    players = get_players_cached(game_id)
    black_before = db.get_rating(players["black"])[0] if players["black"] else None
    white_before = db.get_rating(players["white"])[0] if players["white"] else None

    outcome = db.finalize_rated_game(game_id, winner)
    if outcome is None:
        return  # 不满足结算条件（非rated/有一方匿名/无时间限制/已经结算过），没有变化量可存
    new_black, new_white = outcome
    GAME_RATING_DELTAS[game_id] = {
        "black": {"before": black_before, "after": new_black, "delta": new_black - black_before}
                 if black_before is not None else None,
        "white": {"before": white_before, "after": new_white, "delta": new_white - white_before}
                 if white_before is not None else None,
    }


async def _apply_bot_move_and_broadcast(game_id: str, game: Game, move) -> bool:
    """落子前再确认一次状态没变（AI 思考的这几秒里，人类可能已经认输/悔棋，
    或者对局被取消了），然后落子、存档、广播。返回是否真的走成了这一步——
    调用方（下面的循环）靠这个判断"要不要继续检查下一步是不是还是 bot"。
    """
    game = GAMES.get(game_id)
    if game is None or game.result.value != "ongoing":
        return False
    try:
        record = game.make_move(move.from_sq, move.to_sq)
    except (IllegalMoveError, GameOverError):
        return False  # 防御性兜底：正常不该走到这里（bot 只会选自己认证过的合法招法）

    response = game_state(game_id, game)
    response["last_move"] = move_notation(record)
    await persist(game_id, game)
    maybe_finalize_rating(game_id, game)
    await manager.broadcast(game_id, response)

    if game.result.value != "ongoing":
        bot_controller.mark_game_ended(BOT_SCHEDULER_STATE, game_id)
    return True


async def trigger_ai_move(game_id: str) -> None:
    """
    后台任务：轮到 bot 走棋时调用——覆盖两条完全不同的来源：
        1. Play against AI（GAME_AI 记录的难度选择，不是人格）：AI 执黑
           先手的开局第一步、或者人类走完之后如果该 AI 应招了。
        2. AI 人格自主对局（GAME_PLAYERS 里某一方的用户名本身就是一个
           personas.py 里的人格账号）：不管对面是真人还是另一个 bot 人格
           都适用——如果对面也是 bot，这个函数会自己循环着一直走下去，
           直到轮到真人或者对局结束为止（bot vs bot 表演赛就是这么跑起来的，
           不需要外部一步一步地重复触发）。

    这个函数是在触发它的那次 HTTP 请求已经返回**之后**才跑的（走
    BackgroundTasks 或者调度器的后台循环），bot 算出来的招法通过 WebSocket
    推送给前端，不会让触发它的那次请求被 bot 的思考时间（最长可能到
    深度3的几十秒，见 ai/README.md 的性能记录）拖住。

    play_service.choose_ai_move()/choose_persona_move() 都是纯 CPU 密集型
    同步函数，必须用 run_in_threadpool() 丢进线程池——直接调用会卡住事件
    循环，这段时间服务器处理不了任何别的请求（包括别的对局的心跳/走棋）。
    """
    while True:
        game = GAMES.get(game_id)
        if game is None or game.result.value != "ongoing":
            return

        ai_info = GAME_AI.get(game_id)
        if ai_info is not None and game.current_side.value == ai_info["side"]:
            try:
                result = await run_in_threadpool(
                    play_service.choose_ai_move, game.board, game.current_side, ai_info["difficulty"]
                )
            except Exception:
                return
            if result.best_move is None:
                return
            if not await _apply_bot_move_and_broadcast(game_id, game, result.best_move):
                return
            continue  # 万一双方都恰好是 bot（理论上 vs_ai 不会发生），继续检查下一步

        players = GAME_PLAYERS.get(game_id, {})
        mover_username = players.get(game.current_side.value)
        persona_key = PERSONA_USERNAME_TO_KEY.get(mover_username) if mover_username else None
        if persona_key is None:
            return  # 轮到真人了，或者这一方还没人认领，到此为止

        try:
            result = await run_in_threadpool(
                play_service.choose_persona_move, game.board, game.current_side, persona_key
            )
        except Exception:
            return
        if result.best_move is None:
            return
        if not await _apply_bot_move_and_broadcast(game_id, game, result.best_move):
            return
        # 循环继续：如果对面也是 bot（bot vs bot 表演赛），下一轮会自动检测到


def start_game_if_needed(game: Game) -> bool:
    """
    幂等地"正式开始"一局对局：如果棋钟还没走过（active_side 为 None），
    就调用 start_clocks() 让它从现在开始计时；已经开始过了则什么都不做。
    返回是否真的触发了开始（供调用方决定要不要落盘）。
    """
    if game.clock.is_unlimited:
        return False  # 无时间限制的对局没有"开始计时"这回事
    if game.clock.active_side is not None:
        return False  # 已经开始过了
    game.start_clocks()
    return True


def get_current_user(x_auth_token: str | None) -> str | None:
    """根据请求头里的令牌查找对应的用户名；令牌无效或没提供都返回 None"""
    if not x_auth_token:
        return None
    return TOKENS.get(x_auth_token)


def require_login(x_auth_token: str | None) -> str:
    """跟 get_current_user 一样，但找不到用户时直接抛出 401，供需要登录才能用的接口调用"""
    if not x_auth_token:
        raise HTTPException(status_code=401, detail="需要登录（请在请求头带上 X-Auth-Token）")
    username = TOKENS.get(x_auth_token)
    if username is None:
        raise HTTPException(status_code=401, detail="登录令牌无效或已过期，请重新登录")
    return username


def get_players_cached(game_id: str) -> dict:
    """获取某局对局的黑白双方玩家绑定情况；内存里没有则从数据库读取并缓存"""
    if game_id not in GAME_PLAYERS:
        black, white = db.get_players(game_id)
        GAME_PLAYERS[game_id] = {"black": black, "white": white}
    return GAME_PLAYERS[game_id]


def get_guest_claims(game_id: str) -> dict:
    """获取某局对局的访客身份绑定情况；不存在则初始化一个空的（两边都没人认领）"""
    if game_id not in GAME_GUEST_CLAIMS:
        GAME_GUEST_CLAIMS[game_id] = {"black": None, "white": None}
    return GAME_GUEST_CLAIMS[game_id]


def resolve_my_side(game_id: str, username: str | None, guest_id: str | None) -> str | None:
    """
    判定"发起这次请求的人"到底是这局对局的黑方、白方，还是都不是。
    同时兼容两种身份：登录账号（优先判断）、匿名访客身份。
    这个值是"per-caller"的（每个人看到的都可能不一样），不能塞进
    WebSocket 广播的公共状态里（广播是所有人收到同一份），只应该用在
    "直接返回给发起这次请求的人"的 HTTP 响应里。
    """
    players = get_players_cached(game_id)
    if username is not None:
        if players["black"] == username:
            return "black"
        if players["white"] == username:
            return "white"
    claims = get_guest_claims(game_id)
    if guest_id is not None:
        if claims["black"] == guest_id:
            return "black"
        if claims["white"] == guest_id:
            return "white"
    return None


def authorize_participant(game_id: str, x_auth_token: str | None, x_guest_id: str | None = None) -> str | None:
    """
    校验调用者是否有权对这局对局做出影响状态的操作（悔棋/认输/走棋等）。
    - 如果黑白双方既没有绑定账号、也没有访客身份认领，不做任何限制，返回 None。
    - 如果有账号绑定，调用者必须登录，且必须是这两位玩家之一。
    - 没有账号绑定但有访客身份认领，调用者的 X-Guest-Id 必须匹配其中一方。
    返回调用者的用户名（访客/纯匿名情况下返回 None）。
    """
    players = get_players_cached(game_id)
    claims = get_guest_claims(game_id)

    has_account_binding = players["black"] is not None or players["white"] is not None
    has_guest_binding = claims["black"] is not None or claims["white"] is not None

    if not has_account_binding and not has_guest_binding:
        return None  # 完全没人认领任何一方，不做身份限制

    if has_account_binding:
        username = require_login(x_auth_token)
        if username not in (players["black"], players["white"]):
            raise HTTPException(status_code=403, detail="你不是这局对局的玩家")
        return username

    # 只有访客身份绑定，没有账号绑定
    if x_guest_id not in (claims["black"], claims["white"]):
        raise HTTPException(status_code=403, detail="你不是这局对局的玩家")
    return None


# ---------------------------------------------------------------------------
# 基础接口（保留自第1版，方便随时确认服务是否存活）
# ---------------------------------------------------------------------------

@app.get("/")
def read_root():
    """最基础的接口：访问网站首页，返回一句问候"""
    return {"message": "Arkatana 后端已经跑起来了！"}


# ---------------------------------------------------------------------------
# 账号接口
# ---------------------------------------------------------------------------

@app.post("/register")
def register(body: RegisterRequest):
    """注册新账号"""
    username = body.username.strip()
    if len(username) < 3:
        raise HTTPException(status_code=400, detail="用户名至少需要3个字符")
    if len(body.password) < 6:
        raise HTTPException(status_code=400, detail="密码至少需要6个字符")

    user = db.create_user(username, body.password)
    if user is None:
        raise HTTPException(status_code=409, detail="用户名已被使用")

    return {"username": user.username, "message": "注册成功，请登录"}


@app.post("/login")
def login(body: LoginRequest):
    """登录，成功后返回一个令牌（token），之后的请求在请求头带上
    'X-Auth-Token: <token>' 就能证明"这是谁在操作"。"""
    username = body.username.strip()
    if not db.verify_user_login(username, body.password):
        raise HTTPException(status_code=401, detail="用户名或密码错误")

    token = secrets.token_hex(16)
    TOKENS[token] = username
    return {"token": token, "username": username}


@app.post("/login/google")
def login_google(body: OAuthLoginRequest):
    """
    用 Google 账号登录。前端用 Google Identity Services 的登录按钮
    拿到一个 ID token（一段签名过的 JWT），传给这个接口验证。

    验证通过后：
    - 如果这个 Google 账号之前登录过，直接用回原来关联的本站账号
    - 第一次登录：自动创建一个新账号（用户名从 Google 邮箱前缀生成，
      重复了会自动加数字），不需要用户自己再填用户名密码
    """
    if not GOOGLE_CLIENT_ID:
        raise HTTPException(status_code=500, detail="服务器还没配置 GOOGLE_CLIENT_ID，Google 登录暂不可用")

    try:
        payload = google_id_token.verify_oauth2_token(
            body.credential, google_requests.Request(), GOOGLE_CLIENT_ID
        )
    except ValueError as e:
        raise HTTPException(status_code=401, detail=f"Google 登录凭证无效: {e}")

    google_user_id = payload["sub"]  # Google 给每个用户的唯一ID，长期不变
    email = payload.get("email", "")
    suggested_username = email.split("@")[0] if email else f"google{google_user_id[:6]}"

    user = db.get_or_create_oauth_user("google", google_user_id, suggested_username)

    token = secrets.token_hex(16)
    TOKENS[token] = user.username
    return {"token": token, "username": user.username}


@app.get("/me")
def read_current_user(x_auth_token: str = Security(auth_scheme)):
    """查询当前令牌对应的登录用户，主要用于验证登录流程是否正常"""
    username = require_login(x_auth_token)
    return {"username": username}


@app.get("/users/{username}/rating")
def get_user_rating(username: str):
    """查询某个用户的当前评分（公开信息，不需要登录），用户不存在则返回默认初始评分"""
    rating, games_played = db.get_rating(username)
    return {"username": username, "rating": rating, "games_played": games_played}


# ---------------------------------------------------------------------------
# 对局管理接口
# ---------------------------------------------------------------------------

@app.post("/games")
async def create_game(
    background_tasks: BackgroundTasks,
    body: CreateGameRequest | None = None,
    x_auth_token: str = Security(auth_scheme),
    x_guest_id: str | None = Header(default=None),
):
    """
    创建一局新对局（也就是"开一个房间"）。
    如果携带了有效的登录令牌，可以指定 side_preference：
      - "black"：创建者执黑（先手）
      - "white"：创建者执白（后手）
      - "random"（默认）：随机决定创建者执哪一方
    未登录时，如果请求头带了 X-Guest-Id（浏览器本地生成的访客身份），
    仍然会按 side_preference 认领一方，只是这个身份是"访客"不是真实账号——
    不会存进数据库、不会出现在对局历史里，纯粹用来防止两个不同的匿名访客
    同时操作同一方棋子。完全不带 X-Guest-Id 时才是真正意义上"谁都能走"的对局。

    rated（排位）对局只能随机先后手，不能指定执黑/执白；
    而且 rated 对局必须设置时间控制（不能是无时间限制的"线下对练"模式）。

    vs_ai=True 时创建一局 Play against AI 对局：side_preference 表示"人类想执
    哪一方"，AI 自动拿另一方，用 ai_difficulty 指定的难度思考。这种对局不支持
    rated（AI 不参与排位分），也不能跟 single_device 同时开启。两个"位置"
    创建的这一刻就都确定了，不用等真人加入；如果 AI 恰好执黑（先手），
    创建请求返回之后，AI 的第一步棋会在后台算完再通过 WebSocket 推送过来——
    不会让这次创建请求被 AI 的思考时间拖住。

    时间控制：minutes_per_side 留空表示无时间限制；否则两个数值都必须落在
    约定好的离散档位上（TimeControl 内部会自动校验，不合法会返回 400）。

    棋钟什么时候开始走：不管匿名还是账号对局，创建的这一刻都**不会**开始计时——
    对局会先"晾在大厅里"等人进来，真正开始的时机由 /games/{id}/start 或
    /games/{id}/join（账号对局凑齐两人时）触发，避免创建者一个人干等的时候
    自己的棋钟却在空转。（vs_ai 对局例外——两个位置立刻就确定了，不用等，
    创建成功就直接开始计时。）
    """
    creator = get_current_user(x_auth_token)
    if x_auth_token and creator is None:
        # 带了令牌但服务器查不到——通常是服务器重启过、内存里的登录状态清空了
        # （令牌目前是纯内存存储，这是已知的架构限制）。
        # 不能悄悄当成匿名处理，那会让"明明登录了却建出匿名房间"这种confusing的情况
        # 悄无声息地发生；应该让调用方知道，去重新登录。
        raise HTTPException(status_code=401, detail="登录状态已失效，请重新登录后再创建对局")

    single_device = bool(body.single_device) if body else False
    preference = (body.side_preference if body else "random").strip().lower()
    rated = bool(body.rated) if body else False
    minutes_per_side = body.minutes_per_side if body else None
    increment_seconds = (body.increment_seconds if body else 0) or 0
    vs_ai = bool(body.vs_ai) if body else False
    ai_difficulty = (body.ai_difficulty if body else "medium").strip().lower()

    if single_device and rated:
        raise HTTPException(status_code=400, detail="single game 不支持 rated")
    if single_device:
        minutes_per_side = None  # single game 不显示也不需要时间控制

    if vs_ai and single_device:
        raise HTTPException(status_code=400, detail="vs_ai 不能跟 single_device 同时开启")
    if vs_ai and rated:
        raise HTTPException(status_code=400, detail="AI 对局不支持 rated")
    if vs_ai and not play_service.is_valid_difficulty(ai_difficulty):
        raise HTTPException(status_code=400, detail=f"未知的 AI 难度：{ai_difficulty}")

    if rated and preference != "random":
        raise HTTPException(status_code=400, detail="rated 对局只能随机先后手，不能指定执黑/执白")
    if rated and minutes_per_side is None:
        raise HTTPException(status_code=400, detail="rated 对局必须设置时间控制")

    try:
        time_control = TimeControl(minutes_per_side, increment_seconds) if minutes_per_side is not None else None
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    if creator is not None and not single_device:
        # 登录用户再创建一局之前，先把自己名下还在大厅里等待、没人加入的
        # 旧房间清掉——不然每点一次 Create a game 就多攒一个"僵尸房间"，
        # 大厅会被自己刷屏。single game 不受影响，那是临时对局，本来就
        # 不落库，不会有"堆积"的问题。
        stale_id = db.find_pending_room_for_user(creator)
        if stale_id is not None:
            _discard_game(stale_id)

    game_id = uuid.uuid4().hex[:8]
    GAMES[game_id] = Game(time_control=time_control)

    if single_device:
        # 本机双人对战：同一个人/同一个浏览器操作两边，不认领任何一方
        # （两边都不设归属，走棋权限检查自然对双方都放行），也完全不落库。
        EPHEMERAL_GAMES.add(game_id)
        GAME_PLAYERS[game_id] = {"black": None, "white": None}
        GAME_RATED[game_id] = False
        start_game_if_needed(GAMES[game_id])
        state = game_state(game_id, GAMES[game_id])
        await manager.broadcast(game_id, state)
        return {**state, "my_side": None}

    if vs_ai:
        # Play against AI：另一方由 AI 控制。AI 那一方在 GAME_PLAYERS 里存的是
        # 一个固定的展示名字（比如"🤖 AI（中等）"）而不是真实用户名——没有真人
        # 能以这个名字登录，所以现有的走棋权限校验（比对 X-Auth-Token 对应的
        # 用户名）天然就会拒绝任何人类替 AI 手动走棋，不需要专门加一套机制；
        # 前端渲染玩家名的地方也不用改，直接把这个字符串当成对手名字显示就行。
        human_side = preference if preference in ("black", "white") else random.choice(["black", "white"])
        ai_side = "white" if human_side == "black" else "black"
        ai_name = play_service.ai_display_name(ai_difficulty)

        black_slot = creator if human_side == "black" else ai_name
        white_slot = creator if human_side == "white" else ai_name
        GAME_PLAYERS[game_id] = {"black": black_slot, "white": white_slot}
        GAME_RATED[game_id] = False
        GAME_AI[game_id] = {"side": ai_side, "difficulty": ai_difficulty}

        if creator is None and x_guest_id:
            get_guest_claims(game_id)[human_side] = x_guest_id

        await persist(
            game_id, GAMES[game_id],
            black_player=black_slot, white_player=white_slot, rated=False,
            was_random_side=(preference not in ("black", "white")),
        )

        # 两个位置这一刻就都确定了，不用像人类对局那样等对方 /join，直接开始计时
        # （如果设置了时间控制的话）。
        start_game_if_needed(GAMES[game_id])

        state = game_state(game_id, GAMES[game_id])
        await manager.broadcast(game_id, state)

        if ai_side == "black":
            # AI 执黑先手：创建请求正常速度返回，AI 的第一步棋放到后台算，
            # 算完了自己走、自己存档、自己广播——不能在这里直接 await，
            # 那样会让这次"创建对局"请求被 AI 的思考时间（最长可能到30秒）拖住。
            background_tasks.add_task(trigger_ai_move, game_id)

        return {**state, "my_side": resolve_my_side(game_id, creator, x_guest_id)}

    black_slot: str | None = None
    white_slot: str | None = None

    if creator is not None:
        if preference == "black":
            black_slot = creator
        elif preference == "white":
            white_slot = creator
        else:  # "random" 或其他任何值，一律按随机处理
            if random.choice([True, False]):
                black_slot = creator
            else:
                white_slot = creator

    GAME_PLAYERS[game_id] = {"black": black_slot, "white": white_slot}
    GAME_RATED[game_id] = rated

    if creator is None and x_guest_id:
        claims = get_guest_claims(game_id)
        if preference == "black":
            claims["black"] = x_guest_id
        elif preference == "white":
            claims["white"] = x_guest_id
        else:
            if random.choice([True, False]):
                claims["black"] = x_guest_id
            else:
                claims["white"] = x_guest_id

    await persist(
        game_id, GAMES[game_id],
        black_player=black_slot, white_player=white_slot, rated=rated,
        was_random_side=(preference not in ("black", "white")),
    )

    state = game_state(game_id, GAMES[game_id])
    await manager.broadcast(game_id, state)
    return {**state, "my_side": resolve_my_side(game_id, creator, x_guest_id)}


@app.post("/games/{game_id}/join")
async def join_game(
    background_tasks: BackgroundTasks,
    game_id: str,
    x_auth_token: str = Security(auth_scheme),
):
    """
    登录用户加入一局对局，认领还没人认领的那一方。
    如果两方都已经有人认领，返回错误；如果自己已经在这局里了，也会提示。
    """
    game = get_game_or_404(game_id)  # 确保对局存在（顺带把内存缓存补全）
    username = require_login(x_auth_token)
    players = get_players_cached(game_id)

    if username in (players["black"], players["white"]):
        raise HTTPException(status_code=400, detail="你已经是这局对局的玩家了")

    if players["black"] is None:
        players["black"] = username
    elif players["white"] is None:
        players["white"] = username
    else:
        raise HTTPException(status_code=409, detail="这局对局的黑白双方都已经有人认领了")

    # 刚好把最后一个空位填满：对局正式凑齐两个人，开始计时
    if players["black"] is not None and players["white"] is not None:
        start_game_if_needed(game)

    await persist(game_id, GAMES[game_id], black_player=players["black"], white_player=players["white"])
    state = game_state(game_id, GAMES[game_id])
    await manager.broadcast(game_id, state)

    # 如果这局是某个 AI 人格自主建的房，真人（或者以后的另一个bot）刚把它
    # 填满——通知调度器"这局已经进入正式对局阶段"（触发全暂停，其余 bot
    # 停止建新房，直到这局结束），并且如果恰好轮到 bot 先走（bot 执黑），
    # 立刻放进后台任务去想，不让这次 join 请求被 bot 的思考时间拖住。
    if game_id in {r.game_id for r in BOT_SCHEDULER_STATE.pending_rooms}:
        bot_controller.mark_room_joined(BOT_SCHEDULER_STATE, game_id)
    is_bot_turn = (
        game.result.value == "ongoing"
        and players.get(game.current_side.value) in PERSONA_USERNAME_TO_KEY
    )
    if is_bot_turn:
        background_tasks.add_task(trigger_ai_move, game_id)

    return {**state, "my_side": resolve_my_side(game_id, username, None)}


@app.post("/games/{game_id}/start")
async def start_game(
    game_id: str,
    x_auth_token: str = Security(auth_scheme),
    x_guest_id: str | None = Header(default=None),
):
    """
    正式开始一局对局（棋钟从此刻开始走）。这是"匿名对局"用的入口——
    因为匿名玩家没有账号，没法走 /join 那套"认领身份"的流程，
    所以只要是第二个真正打算下棋的人点了"进入对局"，前端就会调用这个接口。
    如果调用者带着 X-Guest-Id 且这局对局还有没被认领的空位，
    会顺便把那个空位分给这个访客身份（已经认领过的话不会重复处理）。
    棋钟如果已经在走了（比如已经有人触发过），这个接口不会做任何事，
    可以放心重复调用。
    """
    game = get_game_or_404(game_id)
    username = get_current_user(x_auth_token)
    players = get_players_cached(game_id)
    claims = get_guest_claims(game_id)

    if x_guest_id and x_guest_id not in (claims["black"], claims["white"]):
        for side in ("black", "white"):
            if players[side] is None and claims[side] is None:
                claims[side] = x_guest_id
                break

    started_now = start_game_if_needed(game)
    if started_now:
        await persist(game_id, game)
    state = game_state(game_id, game)
    await manager.broadcast(game_id, state)
    return {**state, "my_side": resolve_my_side(game_id, username, x_guest_id)}


def _discard_game(game_id: str) -> None:
    """彻底清掉一局对局的所有痕迹（内存 + 数据库）——用于取消房间/自动顶替旧房间。"""
    GAMES.pop(game_id, None)
    GAME_PLAYERS.pop(game_id, None)
    GAME_GUEST_CLAIMS.pop(game_id, None)
    GAME_RATED.pop(game_id, None)
    GAME_AI.pop(game_id, None)
    EPHEMERAL_GAMES.discard(game_id)
    db.delete_game(game_id)


# ---------------------------------------------------------------------------
# AI 人格自主对局：建房 / 轮转 / 超时 / 全暂停
# ---------------------------------------------------------------------------
# 决策逻辑本身（"现在该建几个房、该关哪几个、轮到谁"）在 ai/bot_controller.py
# 里，是不碰数据库/网络的纯函数，方便单独测试。这里只负责"按决策结果
# 真正去执行"——创建/关闭对局这些有副作用的操作。

async def _create_bot_room(persona_key: str) -> Optional[str]:
    """内部专用：让一个 AI 人格账号在大厅建一个空房间等人加入，跟人类走
    /games 那个接口效果一样（会出现在大厅列表里、rated、有正确的时间控制），
    但绕开了 HTTP 认证那一层——这是服务器自己代表 bot 账号操作，不是一次
    真的 HTTP 请求，没有 X-Auth-Token 可言。

    始终随机先后手（reasons同真人 rated 对局：rated 本来就要求随机先后手，
    不需要也不应该让 bot"选边"）。不立刻走第一步——即使随机到执黑，也要
    等真人（或者以后的 bot 对战功能）加入之后才开始走，理由见
    ai/bot_controller.py 模块说明：建房那一刻还没有对手，抢先走一步没有
    意义，也会让大厅列表看起来"这局其实已经开始了"，容易让人误解。
    """
    persona = PERSONAS[persona_key]
    username = persona.display_name

    try:
        time_control = TimeControl(persona.minutes_per_side, persona.increment_seconds)
    except ValueError:
        return None  # 人格配置的时间控制不合法——不该发生，防御性兜底

    game_id = uuid.uuid4().hex[:8]
    GAMES[game_id] = Game(time_control=time_control)

    if random.choice([True, False]):
        black_slot, white_slot = username, None
    else:
        black_slot, white_slot = None, username

    GAME_PLAYERS[game_id] = {"black": black_slot, "white": white_slot}
    GAME_RATED[game_id] = True

    try:
        await persist(
            game_id, GAMES[game_id],
            black_player=black_slot, white_player=white_slot, rated=True,
            was_random_side=True,
        )
    except Exception:
        _discard_game(game_id)
        return None

    return game_id


async def _bot_scheduler_tick() -> None:
    """调度器的"一次心跳"——算出这一轮该做的事，真正去执行，再把结果写回
    BOT_SCHEDULER_STATE。异常不能让整个后台循环挂掉，所以外层循环会兜底
    捕获，这个函数本身尽量让每一步操作互相独立（一个 bot 建房失败不影响
    其他 bot 照常建房/关房）。
    """
    actions = bot_controller.decide_actions(
        BOT_SCHEDULER_STATE, now=time.time(), bot_order=BOT_ORDER,
    )

    for game_id in actions.close_room_ids:
        _discard_game(game_id)

    created: dict[str, str] = {}
    for persona_key in actions.create_bot_keys:
        game_id = await _create_bot_room(persona_key)
        if game_id is not None:
            created[persona_key] = game_id

    bot_controller.apply_actions(BOT_SCHEDULER_STATE, actions, created, now=time.time())


async def _bot_scheduler_loop() -> None:
    """服务启动时后台常驻跑的循环，每隔 BOT_SCHEDULER_INTERVAL_SECONDS 跑
    一次心跳。单次心跳出的任何异常都吞掉、打日志继续，不能让这个循环
    因为一次偶发错误就彻底停摆——不然网站会在悄无声息中失去所有 AI
    自主建房能力，比直接报错更难发现。
    """
    while True:
        try:
            await _bot_scheduler_tick()
        except Exception as e:
            print(f"[bot_scheduler] 心跳出错，跳过这一轮: {e}")
        await asyncio.sleep(BOT_SCHEDULER_INTERVAL_SECONDS)


BOT_SCHEDULER_INTERVAL_SECONDS = 15  # 检查间隔——远小于5分钟超时，
# 保证"5分钟"这个数字在实际体验上跟设定值差不了太多；太频繁没有意义
# （反正超时是分钟级的），15秒是个折中


@app.post("/games/{game_id}/cancel")
def cancel_game(
    game_id: str,
    x_auth_token: str = Security(auth_scheme),
    x_guest_id: str | None = Header(default=None),
):
    """
    取消一局还在大厅里等待、谁都还没真正加入的房间（创建者反悔/自己点了自己的房间）。
    只有创建者本人（账号或访客身份匹配）能取消；已经有人走过棋的对局不允许取消
    （那种情况应该走认输，不是"当没发生过"）。
    取消后这局对局会被彻底删除，不会留下任何痕迹。
    """
    game = get_game_or_404(game_id)
    if len(game.move_log) > 0:
        raise HTTPException(status_code=409, detail="对局已经开始，不能取消，只能认输")

    authorize_participant(game_id, x_auth_token, x_guest_id)
    _discard_game(game_id)

    return {"cancelled": True}


@app.get("/games/mine")
def list_my_games(limit: int = 20, x_auth_token: str = Security(auth_scheme)):
    """
    列出当前登录用户自己参与过的对局（网页首页"Game History"用这个）。
    需要登录；匿名对局或别人的对局不会出现在这里。
    注意：这个路由必须写在 /games/{game_id} 之前，否则 FastAPI 会把
    "mine" 当成 game_id 处理，永远匹配不到这个接口。
    """
    username = require_login(x_auth_token)
    return {"games": db.list_user_games(username, limit=limit)}


@app.get("/games/{game_id}")
def get_game(
    game_id: str,
    x_auth_token: str = Security(auth_scheme),
    x_guest_id: str | None = Header(default=None),
):
    """查询某局对局当前的完整状态"""
    game = get_game_or_404(game_id)
    username = get_current_user(x_auth_token)
    state = game_state(game_id, game)
    return {**state, "my_side": resolve_my_side(game_id, username, x_guest_id)}


@app.get("/games/{game_id}/legal-moves")
def get_legal_moves(game_id: str, coord: str):
    """查询指定坐标上的棋子，当前有哪些合法走法"""
    game = get_game_or_404(game_id)
    try:
        origin = parse_coord(coord)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    moves = game.legal_moves_from(origin)
    return {
        "coord": coord,
        "legal_destinations": [coord_to_str(*m.to_sq) for m in moves],
    }


@app.post("/games/{game_id}/move")
async def make_move(
    game_id: str,
    move: MoveRequest,
    background_tasks: BackgroundTasks,
    x_auth_token: str = Security(auth_scheme),
    x_guest_id: str | None = Header(default=None),
):
    """
    执行一步棋。
    如果当前轮到走棋的这一方已经绑定了账号，必须以该账号登录才能提交这步棋；
    如果绑定的是匿名访客身份（没有账号，但认领过这一方），
    必须带上匹配的 X-Guest-Id 才能提交；两者都没绑定时不做限制。
    """
    game = get_game_or_404(game_id)
    start_game_if_needed(game)  # 兜底：万一前端没调用 /start 就直接走棋了，这里保证棋钟正确开始

    players = get_players_cached(game_id)
    claims = get_guest_claims(game_id)
    side_key = game.current_side.value
    other_key = "white" if side_key == "black" else "black"
    mover_slot = players[side_key]
    guest_slot = claims[side_key]

    if mover_slot is not None:
        username = require_login(x_auth_token)
        if username != mover_slot:
            raise HTTPException(status_code=403, detail="还没轮到你，这不是你的回合")
    elif guest_slot is not None:
        if x_guest_id != guest_slot:
            raise HTTPException(status_code=403, detail="还没轮到你，这不是你的回合")
    elif players[other_key] is not None:
        # 这一方自己还没被认领（不是账号也不是访客），但对方已经是真实账号了——
        # 说明这是一局"账号对局"，不能让任何路人（不管是别的访客还是恰好
        # 也登录了同一账号的另一个浏览器）不打招呼就直接把这一方的棋走了，
        # 必须先 /join 正式认领这一方才行。
        raise HTTPException(status_code=403, detail="这局对局需要先加入（join）才能走棋")

    try:
        from_sq = parse_coord(move.from_sq)
        to_sq = parse_coord(move.to_sq)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    try:
        record = game.make_move(from_sq, to_sq)
    except IllegalMoveError:
        piece = game.board.get(from_sq)
        if isinstance(piece, Throne):
            raise HTTPException(status_code=400, detail="王城不可移动")
        if is_in_check(game.board, game.current_side):
            raise HTTPException(status_code=400, detail="你的王城正在被攻击")
        raise HTTPException(status_code=400, detail="非法走法")
    except GameOverError as e:
        raise HTTPException(status_code=409, detail=str(e))

    response = game_state(game_id, game)
    response["last_move"] = move_notation(record)
    await persist(game_id, game)
    maybe_finalize_rating(game_id, game)
    await manager.broadcast(game_id, response)

    if game.result.value != "ongoing":
        bot_controller.mark_game_ended(BOT_SCHEDULER_STATE, game_id)

    # 人类这一步刚好让局面轮到了 bot（不管是 Play against AI 的难度选择，
    # 还是大厅里正常配对到的 AI 人格账号）——放进后台任务去想，不在这次
    # 请求里等，免得人类提交这一步之后，页面要卡最长几十秒才收到响应。
    ai_info = GAME_AI.get(game_id)
    next_mover = players.get(game.current_side.value) if (players := GAME_PLAYERS.get(game_id)) else None
    is_bot_turn = (
        game.result.value == "ongoing"
        and (
            (ai_info is not None and game.current_side.value == ai_info["side"])
            or (next_mover in PERSONA_USERNAME_TO_KEY)
        )
    )
    if is_bot_turn:
        background_tasks.add_task(trigger_ai_move, game_id)

    my_side = resolve_my_side(game_id, get_current_user(x_auth_token), x_guest_id)
    return {**response, "my_side": my_side}


@app.post("/games/{game_id}/undo")
async def undo_move(
    game_id: str,
    x_auth_token: str = Security(auth_scheme),
    x_guest_id: str | None = Header(default=None),
):
    """悔棋。如果这局对局绑定了账号或访客身份，必须是黑方或白方玩家本人才能悔棋。"""
    game = get_game_or_404(game_id)
    authorize_participant(game_id, x_auth_token, x_guest_id)
    try:
        game.undo()
    except IllegalMoveError as e:
        raise HTTPException(status_code=400, detail=str(e))
    await persist(game_id, game)
    state = game_state(game_id, game)
    await manager.broadcast(game_id, state)
    my_side = resolve_my_side(game_id, get_current_user(x_auth_token), x_guest_id)
    return {**state, "my_side": my_side}


@app.post("/games/{game_id}/resign")
async def resign(
    game_id: str,
    body: ResignRequest,
    x_auth_token: str = Security(auth_scheme),
    x_guest_id: str | None = Header(default=None),
):
    """指定一方认输。如果这局对局绑定了账号或访客身份，只能替自己那一方认输。"""
    game = get_game_or_404(game_id)
    if game.result.value != "ongoing":
        raise HTTPException(status_code=409, detail="对局已结束")
    side_key = body.side.strip().lower()
    if side_key not in ("black", "white"):
        raise HTTPException(status_code=400, detail="side 字段必须是 'black' 或 'white'")

    players = get_players_cached(game_id)
    claims = get_guest_claims(game_id)
    resigning_slot = players[side_key]
    resigning_guest = claims[side_key]

    if resigning_slot is not None:
        username = require_login(x_auth_token)
        if username != resigning_slot:
            raise HTTPException(status_code=403, detail="只能替自己那一方认输")
    elif resigning_guest is not None:
        if x_guest_id != resigning_guest:
            raise HTTPException(status_code=403, detail="只能替自己那一方认输")

    side = Side.BLACK if side_key == "black" else Side.WHITE
    game.resign(side)
    await persist(game_id, game)
    maybe_finalize_rating(game_id, game)
    state = game_state(game_id, game)
    await manager.broadcast(game_id, state)
    my_side = resolve_my_side(game_id, get_current_user(x_auth_token), x_guest_id)
    return {**state, "my_side": my_side}


@app.post("/games/{game_id}/offer")
async def make_offer(
    game_id: str,
    body: OfferRequest,
    x_auth_token: str = Security(auth_scheme),
    x_guest_id: str | None = Header(default=None),
):
    """
    发起悔棋（retake）或和棋（draw）申请，等对方同意/拒绝。

    各项限制：
      - 悔棋只能在 casual 对局里用，rated 对局不允许
      - 同一局同时只能有一个待处理的申请
      - 被拒绝后 60 秒内不能再提同一类申请
      - 提和每方最多 2 次，用完之后一律拒绝并提示
    """
    game = get_game_or_404(game_id)
    if game.result.value != "ongoing":
        raise HTTPException(status_code=409, detail="对局已结束")

    kind = body.kind.strip().lower()
    if kind not in ("retake", "draw"):
        raise HTTPException(status_code=400, detail="kind 必须是 'retake' 或 'draw'")

    my_side = resolve_my_side(game_id, get_current_user(x_auth_token), x_guest_id)
    if my_side is None:
        raise HTTPException(status_code=403, detail="你不是这局对局的玩家")

    if kind == "retake":
        if GAME_RATED.get(game_id, False):
            raise HTTPException(status_code=403, detail="rated 对局不能悔棋")
        if len(game.move_log) == 0:
            raise HTTPException(status_code=400, detail="还没有可以悔的棋")

    if game_id in GAME_OFFERS:
        raise HTTPException(status_code=409, detail="已经有一个待处理的申请了")

    # 60 秒冷却
    cooldowns = GAME_COOLDOWN.setdefault(game_id, {})
    ready_at = cooldowns.get((my_side, kind))
    now = time.time()
    if ready_at is not None and now < ready_at:
        if kind == "draw":
            raise HTTPException(status_code=429, detail="do not repeatedly offer a draw!")
        raise HTTPException(
            status_code=429,
            detail=f"请等待 {int(ready_at - now) + 1} 秒后再次提出悔棋",
        )

    if kind == "draw":
        counts = GAME_DRAW_COUNT.setdefault(game_id, {"black": 0, "white": 0})
        if counts[my_side] >= MAX_DRAW_OFFERS_PER_SIDE:
            raise HTTPException(status_code=429, detail="do not repeatedly offer a draw!")
        counts[my_side] += 1

    GAME_OFFERS[game_id] = {"kind": kind, "from": my_side}
    state = game_state(game_id, game)
    await manager.broadcast(game_id, state)
    return {**state, "my_side": my_side}


@app.post("/games/{game_id}/offer/respond")
async def respond_to_offer(
    game_id: str,
    body: OfferResponseRequest,
    x_auth_token: str = Security(auth_scheme),
    x_guest_id: str | None = Header(default=None),
):
    """
    回应对方的悔棋/和棋申请。
    同意悔棋 -> 退回到提出方上一次走棋之前（可能要退两步，
    因为对手在那之后通常已经应了一手）。
    同意和棋 -> 对局判和。
    拒绝     -> 申请作废，提出方进入 60 秒冷却。
    """
    game = get_game_or_404(game_id)
    offer = GAME_OFFERS.get(game_id)
    if offer is None:
        raise HTTPException(status_code=404, detail="当前没有待处理的申请")

    my_side = resolve_my_side(game_id, get_current_user(x_auth_token), x_guest_id)
    if my_side is None:
        raise HTTPException(status_code=403, detail="你不是这局对局的玩家")
    if my_side == offer["from"]:
        raise HTTPException(status_code=403, detail="不能回应自己发出的申请")

    kind = offer["kind"]
    GAME_OFFERS.pop(game_id, None)

    if not body.accept:
        # 拒绝：提出方进入冷却
        GAME_COOLDOWN.setdefault(game_id, {})[(offer["from"], kind)] = (
            time.time() + OFFER_COOLDOWN_SECONDS
        )
    else:
        if kind == "draw":
            game.result = GameResult.DRAW
        else:
            # 悔棋：一直退到轮回提出方走棋为止
            # （通常是退两步：对方的应手 + 提出方自己那一步）
            steps = 0
            while game.current_side.value != offer["from"] and len(game.move_log) > 0 and steps < 2:
                game.undo()
                steps += 1
            if game.current_side.value != offer["from"] and len(game.move_log) > 0:
                game.undo()
        await persist(game_id, game)
        maybe_finalize_rating(game_id, game)

    state = game_state(game_id, game)
    await manager.broadcast(game_id, state)
    return {**state, "my_side": my_side}


@app.get("/lobby")
def get_lobby(limit: int = 20):
    """列出大厅里正在等待对手的开放房间（恰好只有一方绑定了账号的对局）"""
    return {"rooms": db.list_open_rooms(limit=limit)}


@app.get("/database/search")
def search_database(
    player: str | None = None,
    opponent: str | None = None,
    rated: bool | None = None,
    date_from: str | None = None,
    date_to: str | None = None,
    limit: int = 20,
    offset: int = 0,
):
    """
    搜索全站对局库（"Database" 页面用这个）。公开接口，不需要登录——
    浏览已经结束的对局本来就是开放给所有人的功能。
    参数含义详见 db.search_games 的说明；日期格式必须是 "YYYY-MM-DD"，
    格式不对会返回 400。
    """
    try:
        return db.search_games(
            player=player, opponent=opponent, rated=rated,
            date_from=date_from, date_to=date_to,
            limit=min(limit, 100), offset=max(offset, 0),
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=f"日期格式不对，请用 YYYY-MM-DD: {e}")


@app.get("/games")
def list_games(limit: int = 20):
    """列出最近更新过的对局摘要（内部/管理用途，不是网页首页"Game History"用的那个）"""
    return {"games": db.list_recent_games(limit=limit)}


@app.get("/games/{game_id}/history")
def get_history(game_id: str):
    """查看整局走子记录（记谱格式文本）"""
    game = get_game_or_404(game_id)
    return {"history": format_game(game.move_log)}


@app.get("/games/{game_id}/replay")
def get_replay(game_id: str):
    """
    复盘：逐步返回这局对局每一步棋之后的完整棋盘状态（JSON格式），
    供前端做"一步步回放"的复盘界面。对局不存在则返回 404。
    """
    if not db.game_exists(game_id):
        raise HTTPException(status_code=404, detail=f"找不到对局 ID: {game_id}")

    try:
        steps = db.replay_steps(game_id)
        result = []
        for step in steps:
            board, _ = position_string_to_board(step["position"])
            result.append({
                "move_number": step["move_number"],
                "side": step["side"],
                "notation": step["notation"],
                "from_sq": step.get("from_sq"),
                "to_sq": step.get("to_sq"),
                "in_check": step.get("in_check", False),
                "board": board_to_json(board),
            })
        # 第0步（还没走任何棋）的初始局面也要给前端——
        # 浏览历史时"回到最开始"需要它，光有每步之后的局面是不够的
        initial_board = board_to_json(setup_initial_board())
    except Exception as e:
        # 常见原因：这局对局是用旧版记谱格式存的，现在的解析器读不懂了
        # （记谱格式在开发过程中调整过，早期存的数据可能跟当前版本不兼容）
        raise HTTPException(
            status_code=422,
            detail=f"这局对局的棋谱回放失败，可能是用旧格式存储的历史数据: {type(e).__name__}: {e}",
        )
    return {"game_id": game_id, "initial_board": initial_board, "steps": result}


# ---------------------------------------------------------------------------
# WebSocket：实时围观某一局对局
# ---------------------------------------------------------------------------

@app.websocket("/ws/games/{game_id}")
async def game_socket(websocket: WebSocket, game_id: str):
    """
    连接后立即推送一次当前对局状态；之后每当有人走棋/悔棋/认输/加入，
    都会自动收到最新状态，不需要客户端主动发消息或轮询。
    """
    try:
        game = get_game_or_404(game_id)
    except HTTPException:
        await websocket.close(code=4404)
        return

    await manager.connect(game_id, websocket)
    try:
        await websocket.send_json(game_state(game_id, game))
        while True:
            # 目前不处理客户端发来的具体内容，只用来检测连接是否还活着
            await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(game_id, websocket)
